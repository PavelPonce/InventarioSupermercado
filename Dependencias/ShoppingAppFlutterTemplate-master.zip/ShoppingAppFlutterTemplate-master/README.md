# ShoppingAppFlutterTemplate
Shopping app template using [Flutter](https://flutter.dev)



<img src="https://github.com/emadghasempour/ShoppingAppFlutterTemplate/blob/master/screenshots/main.png" width="300"> | <img src="https://github.com/emadghasempour/ShoppingAppFlutterTemplate/blob/master/screenshots/details.png" width="300">
